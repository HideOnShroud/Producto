<?php

return [
    'host' => 'localhost',
    'port' => '33066',
    'database' => 'producto',
    'username' => 'root',
    'password' => '',
    'charset' => 'utf8mb4',
];
